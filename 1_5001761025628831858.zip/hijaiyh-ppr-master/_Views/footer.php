<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/jquery.min.js"></script>
<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/jquery.js"></script>
<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/jquery.dataTables.min.js"></script>
<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/dataTables.bootstrap4.min.js"></script>
<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/popper.min.js"></script>
<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/bootstrap.min.js"></script>
<script language="JavaScript" type="text/javascript" src="<?=base_url();?>/assets/js/bsadmin.js"></script>
<script>
    $(document).ready(function()
    {
        //alert('aowkoawkao');
        $('#datatable').DataTable();
        $('#datatable1').DataTable();

    });
    </script>
</body>
</html>